//oncontextmenu
iframes = document.getElementsByTagName("IFRAME");
for (i=0;i<iframes.length;i++) {
	frame_id = "";
	frame_name = "";
	if (iframes[i].id) {frame_id = iframes[i].id;}
	if (iframes[i].getAttribute("name")) {frame_name = iframes[i].getAttribute("name");}
	iframes[i].outerHTML ="<div><span style='color: red'><b>this is an iframe (id:" + frame_id + "/name:" + frame_name + ")</b></span><span style='color: black'>, if you want to inspect iframe elements. navigate to its source : </span><br><br><a href='" + iframes[i].src + "'>" + iframes[i].src + "</a><br><br><span style='color: black'>If you automate tests, you may have to switch in iframe before acting on elements.</span></div>";
}	

objects = document.getElementsByTagName("OBJECT");
for (i=0;i<objects.length;i++) {
	frame_id = "";
	frame_name = "";
	if (objects[i].id) {frame_id = objects[i].id;}
	if (objects[i].getAttribute("name")) {frame_name = objects[i].getAttribute("name");}
	objects[i].outerHTML ="<div><span style='color: red'><b>this is an object (id:" + frame_id + "/name:" + frame_name + ")</b></span><span style='color: black'>, if you want to inspect object elements. navigate to its source : </span><br><br><a href='" + objects[i].data + "'>" + objects[i].data + "</a><br><br><span style='color: black'>If you automate tests, you may have to switch in iframe before acting on elements.</span></div>";
}	


//document.onkeyup = function (e) {
document.oncontextmenu = function (e) {
		allatribute = document.getElementById('extension_all_attributes').value;

		typeinfo = document.getElementById('extension_type_info').value.split("|");
		nbparent = parseInt(typeinfo[1]);
	
        e.preventDefault();
        x = e.clientX;
        y = e.clientY;
        el = e.target;
		myelement = el;
		if (myelement.id == "extension_span") {
			myelement.parentNode.removeChild(myelement);
		} else {
		atts = el.attributes;
		stringelxpath = "/" + el.tagName ;
		stringinfo = "tagName : " + el.tagName + "<br>" ;
		findonetext = false;
		if (el.textContent) {
			stringelxpath += "[contains(., \"" + el.textContent.trim()  + "\")]";
			findonetext = true;
		}
		Array.prototype.slice.call(el.attributes).forEach(function(item) {
			if (allatribute.indexOf("|" + item.name + "|false") < 0) { 
				stringelxpath += "[@" + item.name + "=\"" + item.value + "\"]";
				stringinfo += item.name + "= '" + item.value + "'";
				if (item.name == 'id') {
					stringinfo += "&nbsp;<input type='text' id='extension_element_set_name' placeholder='set name before add to csv'/>&nbsp;<button onclick='var name = \"set_name\";if (document.getElementById(\"extension_element_set_name\").value != \"\") {name = document.getElementById(\"extension_element_set_name\").value};document.getElementById(\"extension_elements_csv\").value = document.getElementById(\"extension_elements_csv\").value + \"\\n\" + name + \";:id;" + item.value + ";set_description\";document.getElementById(\"extension_alfyft_csv\").value = document.getElementById(\"extension_elements_csv\").value;document.getElementById(\"extension_alfyft_csv\").style.display=\"block\";'>add to csv</button>";
					stringinfo += "&nbsp;<button onclick='document.getElementById(\"extension_alfyft_csv\").value = document.getElementById(\"extension_elements_csv\").value;document.getElementById(\"extension_alfyft_csv\").style.display=\"block\";'>show csv</button>";
				}
				if (item.name == 'name') {
					stringinfo += "&nbsp;<input type='text' id='extension_element_set_name' placeholder='set name before add to csv'/>&nbsp;<button onclick='var name = \"set_name\";if (document.getElementById(\"extension_element_set_name\").value != \"\") {name = document.getElementById(\"extension_element_set_name\").value};document.getElementById(\"extension_elements_csv\").value = document.getElementById(\"extension_elements_csv\").value + \"\\n\" + name + \";:name;" + item.value + ";set_description\";document.getElementById(\"extension_alfyft_csv\").value = document.getElementById(\"extension_elements_csv\").value;document.getElementById(\"extension_alfyft_csv\").style.display=\"block\";'>add to csv</button>";
					stringinfo += "&nbsp;<button onclick='document.getElementById(\"extension_alfyft_csv\").value = document.getElementById(\"extension_elements_csv\").value;document.getElementById(\"extension_alfyft_csv\").style.display=\"block\";'>show csv</button>";
				}
				stringinfo += "<br>"
			}
			if (allatribute.indexOf("|" + item.name + "|") < 0) {
				allatribute += "|" + item.name + "|false"; 
			}
		});
		
		stringtotxpath = stringelxpath;
		stringinfo += "<br><b>Parents :</b><br>" ;
		try {
		for (i=0;i<nbparent;i++) {
		el = el.parentNode;
		if (el != null) {
			stringelxpath = "/" + el.tagName ;
			if (el.textContent && findonetext==false) {
				stringelxpath += "[contains(., \"" + el.textContent.trim()  + "\")]";
				findonetext = true;
			}
			stringinfo += "<br>tagName : " + el.tagName + "<br>" ;
			Array.prototype.slice.call(el.attributes).forEach(function(item) {
				if (allatribute.indexOf("|" + item.name + "|false") < 0) { 
					stringelxpath += "[@" + item.name + "=\"" + item.value + "\"]";
					stringinfo += item.name + "= '" + item.value + "'<br>";
				}
				if (allatribute.indexOf("|" + item.name + "|") < 0) {
					allatribute += "|" + item.name + "|false"; 
				}
			});
			stringtotxpath = stringelxpath + stringtotxpath;
		} else {
			i=nbparent;
		}
		}
		} catch(e) {
		}
		stringtotxpath = "/" + stringtotxpath;
		document.getElementById('extension_all_attributes').value = allatribute;
		
		if (document.getElementById('extension_span')==null) {
			var div = document.createElement('div');
			div.setAttribute('id', 'extension_span');
			div.setAttribute('style', 'display: block; position: fixed;top: 0;right: 0;bottom: 0;left: 0;opacity:1;z-index: 9999; padding-top: 100px; left: 10%; top: 20%; width: 80%; height: 60%; overflow: auto; background-color: rgb(0,0,0); background-color: rgba(0,0,0,0.4);');
			document.body.insertBefore(div, document.body.firstChild);
		}
		
		if (document.getElementById('extension_element_path')==null) {
			var inputpath = document.createElement('input');
			inputpath.setAttribute('type', 'hidden');
			inputpath.setAttribute('id', 'extension_element_path');
			inputpath.setAttribute('value', '');
			document.body.appendChild(inputpath);
		}
		
		if (document.getElementById('extension_elements_csv')==null) {
			var inputcsv = document.createElement('input');
			inputcsv.setAttribute('type', 'hidden');
			inputcsv.setAttribute('id', 'extension_elements_csv');
			inputcsv.setAttribute('value', '');
			document.body.appendChild(inputcsv);
		}
		
		if (typeinfo[0]=='xpath') {
			document.getElementById('extension_element_path').value = stringtotxpath;
			innerHTM = "<div style='background-color: #fefefe; margin: auto; padding: 20px; border: 1px solid #888; width: 90%;color: black;'>";
			innerHTM += "<span style='color: #aaaaaa;float: right;font-size: 28px;font-weight: bold;cursor: pointer;' onclick='this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);'>&times;</span><span style='font-family:Arial;font-size:12px;'><b>Element xpath :</b><br>" + stringtotxpath + "<br></span>";
			innerHTM += "<br>&nbsp;<input type='text' id='extension_element_set_name' placeholder='set name before add to csv'/>&nbsp;<button onclick='var name = \"set_name\";if (document.getElementById(\"extension_element_set_name\").value != \"\") {name = document.getElementById(\"extension_element_set_name\").value};document.getElementById(\"extension_elements_csv\").value = document.getElementById(\"extension_elements_csv\").value + \"\\n\" + name + \"|;|:xpath|;|\" + document.getElementById(\"extension_element_path\").value + \"|;|set_description\";document.getElementById(\"extension_alfyft_csv\").value = document.getElementById(\"extension_elements_csv\").value;document.getElementById(\"extension_alfyft_csv\").style.display=\"block\";'>add to csv</button>";
			innerHTM += "&nbsp;<button onclick='document.getElementById(\"extension_alfyft_csv\").value = document.getElementById(\"extension_elements_csv\").value;document.getElementById(\"extension_alfyft_csv\").style.display=\"block\";'>show csv</button>";
			innerHTM += "<br><textarea id='extension_alfyft_csv' cols=100 rows=20 style='display: none' onchange='document.getElementById(\"extension_elements_csv\").value = document.getElementById(\"extension_alfyft_csv\").value;'></textarea>";
			innerHTM += "</div>"
			
			document.getElementById('extension_span').innerHTML = innerHTM;
		} else {
			innerHTM = "<div style='background-color: #fefefe; margin: auto; padding: 20px; border: 1px solid #888; width: 90%;color: black;'><span style='color: #aaaaaa;float: right;font-size: 28px;font-weight: bold;cursor: pointer;' onclick='this.parentNode.parentNode.parentNode.removeChild(this.parentNode.parentNode);'>&times;</span><span style='font-family:Arial;font-size:12px;'>";
			innerHTM += "<b>Element informations :</b><br>" + stringinfo + "</span>"
			innerHTM += "<br><textarea id='extension_alfyft_csv' cols=100 rows=20 style='display: none' onchange='document.getElementById(\"extension_elements_csv\").value = document.getElementById(\"extension_alfyft_csv\").value;'></textarea>";
			innerHTM += "</div>";
			document.getElementById('extension_span').innerHTML = innerHTM;
		}
	}
}

