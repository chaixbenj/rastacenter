chrome.runtime.onMessage.addListener(function (msg, sender) {
    chrome.pageAction.show(sender.tab.id);
});

chrome.pageAction.onClicked.addListener(function(tab){
  chrome.windows.create({
  url: chrome.runtime.getURL("localize.html"),
  type: "popup"
  }, function(win){
  vid = win.id;
  });
});