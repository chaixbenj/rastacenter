
function find() {
	findel();
	wait(1000);
	findel();
}

function findel() {
  var strategy = document.getElementById('strategy').value;
  var chemin = document.getElementById('path').value.replace(/"/g, "\\\""); 
  chrome.tabs.executeScript({code: "if (document.getElementById('extension_strategie_find')==null) {var inputstrat = document.createElement('input');inputstrat.setAttribute('type', 'hidden');inputstrat.setAttribute('id', 'extension_strategie_find');inputstrat.setAttribute('value', '" + strategy + "');document.body.appendChild(inputstrat);} else {document.getElementById('extension_strategie_find').value= '" + strategy + "';}"});
  chrome.tabs.executeScript({code: "if (document.getElementById('extension_path_find')==null) {var inputpath = document.createElement('input');inputpath.setAttribute('type', 'hidden');inputpath.setAttribute('id', 'extension_path_find');inputpath.setAttribute('value', \"" + chemin + "\");document.body.appendChild(inputpath);} else {document.getElementById('extension_path_find').value= \"" + chemin + "\";}"});
  chrome.tabs.executeScript({file: "find.js"});
  chrome.tabs.executeScript({code: "document.getElementById('extension_element_found').value;"}, receiveText);
}

function wait(ms){
   var start = new Date().getTime();
   var end = start;
   while(end < start + ms) {
     end = new Date().getTime();
  }
}

function receiveText(resultsArray){
    //alert("func " + resultsArray[0]);
	document.getElementById('resultfind').innerHTML = "<span><b>" + resultsArray[0] + "</b></span>";
}

function info() {
	if (!localStorage['ext_info_type'])	{
		localStorage['ext_info_type']="xpath";
	} 
	if (!localStorage['ext_info_nb_parent'])	{
		localStorage['ext_info_nb_parent']=3;
	} 
	if (!localStorage['ext_all_attribute_type'])	{
		localStorage['ext_all_attribute_type']="";
	} 

	var type_info = localStorage['ext_info_type'];	
	var all_attributes = localStorage['ext_all_attribute_type'];	
	nbparent = localStorage['ext_info_nb_parent'];
	try {
		if (document.getElementById('info').checked) {
			type_info = "info";
		} else {
			type_info = "xpath";
		}
		var nbparent = document.getElementById('nbelem').value;
	} catch(e) {
		
	}
	localStorage['ext_info_type'] = type_info;
	localStorage['ext_info_nb_parent'] = nbparent;
	type_info += "|" + nbparent;
	
	chrome.tabs.executeScript({code: "if (document.getElementById('extension_type_info')==null) {var inputtypeinfo = document.createElement('input');inputtypeinfo.setAttribute('type', 'hidden');inputtypeinfo.setAttribute('id', 'extension_type_info');inputtypeinfo.setAttribute('value', '" + type_info + "');document.body.appendChild(inputtypeinfo);} else {document.getElementById('extension_type_info').value= '" + type_info + "';}"});
	chrome.tabs.executeScript({code: "if (document.getElementById('extension_all_attributes')==null) {var inputallattr = document.createElement('input');inputallattr.setAttribute('type', 'hidden');inputallattr.setAttribute('id', 'extension_all_attributes');inputallattr.setAttribute('value', '" + all_attributes + "');document.body.appendChild(inputallattr);}"});
	chrome.tabs.executeScript({file: "info.js"});
	chrome.tabs.executeScript({code: "document.getElementById('extension_element_path').value;"}, receivePath);
	majattribview();
}

function receivePath(resultsArray){
	if (document.getElementById('csvimport')) {
	document.getElementById('csvimport').value += resultsArray[0];}
}

function getattribview() {
	chrome.tabs.executeScript({code: "document.getElementById('extension_all_attributes').value;"}, function(result) {localStorage['ext_all_attribute_type_int'] = result});
}

function buildattribview() {
	if (localStorage['ext_all_attribute_type_int']) {
		localStorage['ext_all_attribute_type'] = localStorage['ext_all_attribute_type_int'];
	}
	var div = document.querySelector('#attributes');
	if (div) {
		var allattributes = localStorage['ext_all_attribute_type'].split(";");
		contentatt = "<table><tr><td colspan='8'><b>Attributes<br><span style='color: green;'>(content is updated during navigation) </span></b></td></tr>";
		contentatt += "<tr>";
		for (i=0;i<allattributes.length;i++) {
			if (i%5==1 && i != 1) {contentatt += "</tr><tr>"}
			if (allattributes[i].split("=").length==2) {
				if (allattributes[i].split("=")[1]=='true') {
					contentatt += "<td><input type='checkbox' name='checkattrib' id='id_" + allattributes[i].split("=")[0] + "' checked value=" + allattributes[i].split("=")[0] + " onclick='rebuildattribstring();'></input><span>" + allattributes[i].split("=")[0] + "</span></td>";	
				} else {
					contentatt += "<td><input type='checkbox' name='checkattrib' id='id_" + allattributes[i].split("=")[0] + "'value=" + allattributes[i].split("=")[0] + " onclick='rebuildattribstring();'></input><span>" + allattributes[i].split("=")[0] + "</span></td>";
				}
			}
		}
		contentatt += "</tr></table>";

		div.innerHTML = contentatt;
		checkboxes = document.getElementsByName('checkattrib');
		for (i=0;i<checkboxes.length;i++) {
			document.querySelector('#' + checkboxes[i].id ).addEventListener('click', rebuildattribstring);
		}
	}
}

function uncheckallattr() {
	stringattrib = "";
	checkboxes = document.getElementsByName('checkattrib');
	for (i=0;i<checkboxes.length;i++) {
		checkboxes[i].checked = false;
		stringattrib += ";" + checkboxes[i].value;
		stringattrib += "=false";
	}
	localStorage['ext_all_attribute_type'] = stringattrib;
	localStorage['ext_all_attribute_type_int'] = stringattrib;
	chrome.tabs.executeScript({code: "document.getElementById('extension_all_attributes').value='" + stringattrib + "';"});
}

function majattribview() {
	getattribview();
	buildattribview();
}



function rebuildattribstring() {
	stringattrib = "";
	checkboxes = document.getElementsByName('checkattrib');
	for (i=0;i<checkboxes.length;i++) {
		stringattrib += ";" + checkboxes[i].value;
		if (checkboxes[i].checked) {
			stringattrib += "=true";
		} else {
			stringattrib += "=false";
		}
	}
	localStorage['ext_all_attribute_type'] = stringattrib;
	localStorage['ext_all_attribute_type_int'] = stringattrib;
	chrome.tabs.executeScript({code: "document.getElementById('extension_all_attributes').value='" + stringattrib + "';"});
}

function hide() {
	document.getElementById('hide').style.display='none';
	document.getElementById('findcache').style.display='block';
	document.getElementById('show').style.display='block';
	document.getElementById('content').style.display='none';
}

function show() {
	document.getElementById('content').style.width='auto';
	document.getElementById('hide').style.display='block';
	document.getElementById('findcache').style.display='none';
	document.getElementById('show').style.display='none';
	document.getElementById('content').style.display='block';	
}


document.addEventListener('DOMContentLoaded', function () {
	document.querySelector('#find').addEventListener('click', find);
});

document.addEventListener('DOMContentLoaded', function () {
	document.querySelector('#findcache').addEventListener('click', find);
});

document.addEventListener('DOMContentLoaded', function () {
	document.querySelector('#xpath').addEventListener('click', info);
	if (localStorage['ext_info_type']=="xpath") {document.querySelector('#xpath').checked=true;}
});

document.addEventListener('DOMContentLoaded', function () {
	document.querySelector('#info').addEventListener('click', info);
	if (localStorage['ext_info_type']=="info") {document.querySelector('#info').checked=true;}
});

document.addEventListener('DOMContentLoaded', function () {
	document.querySelector('#nbelem').addEventListener('change', info);
	document.querySelector('#nbelem').value = localStorage['ext_info_nb_parent'];
});

document.addEventListener('DOMContentLoaded', function () {
	document.querySelector('#hide').addEventListener('click', hide);
});

document.addEventListener('DOMContentLoaded', function () {
	document.querySelector('#show').addEventListener('click', show);
});

document.addEventListener('DOMContentLoaded', function () {
	document.querySelector('#maj').addEventListener('click', majattribview);
});

document.addEventListener('DOMContentLoaded', function () {
	document.querySelector('#uncheckall').addEventListener('click', uncheckallattr);
});

document.addEventListener('DOMContentLoaded', function () {
	majattribview();
});

if (!localStorage['ext_info_type'])	{
	localStorage['ext_info_type']="xpath";
} 
if (!localStorage['ext_info_nb_parent'])	{
	localStorage['ext_info_nb_parent']=3;
} 
if (!localStorage['ext_all_attribute_type'])	{
	if (!localStorage['ext_all_attribute_type_int'])	{
		localStorage['ext_all_attribute_type']="";
	} else {
		localStorage['ext_all_attribute_type']=localStorage['ext_all_attribute_type_int'];
	}
} 

info();
