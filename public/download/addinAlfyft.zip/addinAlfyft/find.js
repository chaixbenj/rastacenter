strategy = document.getElementById('extension_strategie_find').value;
chemin = document.getElementById('extension_path_find').value;

if (document.getElementById('extension_element_found')==null) {
	var inputfound = document.createElement('input');inputpath.setAttribute('type', 'hidden');
	inputfound.setAttribute('id', 'extension_element_found');
	document.body.appendChild(inputfound);
}


element=null;
try {
	if (strategy=='id') {
		element = document.getElementById(chemin);
	}
	if (strategy=='name') {
		elements = document.getElementsByName(chemin);
		if (elements != null) {
			element = elements[0];
		}
	}
	if (strategy=='xpath') {
		element = document.evaluate( chemin ,document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null ).singleNodeValue;
	}

	if (element != null) {
		highlight(element);
		document.getElementById('extension_element_found').value = "found";
	} else {
		document.getElementById('extension_element_found').value = "not found";
	}

} catch(e) {
	document.getElementById('extension_element_found').value = e;
}


function highlight(element) {
	styleParentElem = "background-color: pink; border-style: solid; border-color: pink;";
	styleElem = "background-color: red; border-style: solid; border-color: red;";
	
	
	element.scrollIntoView(true);
	typeelement = element.tagName;
	var styleparentbefore = element.parentNode.style;
	var styleoffsetparentbefore = element.offsetParent.style;
	var styleelembefore = element.style;
	element.parentNode.style = styleParentElem;
	element.offsetParent.style = styleParentElem;
	element.style = styleElem;
	setTimeout(function(){           
		element.parentNode.style = styleparentbefore;
		element.offsetParent.style = styleoffsetparentbefore;
		element.style = styleelembefore;
	}, 500);
	
}







